# Build QuickBill APK using only your phone

This project includes a GitHub Actions cloud build workflow. You do not need Android Studio on your phone.

1. Sign in to GitHub in your phone browser and create a **public or private** repository named `quickbill-android`.
2. Extract this ZIP on your phone using your Files app (or a ZIP utility).
3. Upload the contents of the `quickbill_android` folder to the root of the GitHub repository. Make sure `.github/workflows/build-apk.yml` is included. If the GitHub mobile upload page hides dot-folders, use GitHub's web interface in Desktop site mode or upload the ZIP to a computer later.
4. Open the repository's **Actions** tab.
5. Select **Build QuickBill Android APK** and tap **Run workflow**.
6. Wait for the workflow to finish successfully.
7. Open that completed run, scroll to **Artifacts**, and download `QuickBill-debug-APK`.
8. Extract the downloaded artifact ZIP. Tap `app-debug.apk` to install it. Android may ask you to allow installs from your browser or Files app.

This produces a debug APK for personal testing, not a Play Store release. Keep the GitHub repository private if you do not want the app source public.
