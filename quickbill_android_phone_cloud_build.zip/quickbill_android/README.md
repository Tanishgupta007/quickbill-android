# QuickBill — BRIGHT WAYS

Android-wrapper source package for the QuickBill billing app.

## Included fixes
- Amount display is read-only, non-focusable, and uses `inputmode="none"`; programmatic focus calls have been removed to avoid opening the phone keyboard alongside the in-app keypad.
- Bills are saved automatically to local history when **Generate Bill** is tapped.
- History save errors are caught and surfaced instead of silently failing.
- Bill numbering increments based on the highest saved bill number.
- Save/done control state is reset when opening and closing old receipts.
- Added **Import previous bill backup** to History so browser-version bills can be migrated into the APK.

## Android build
See [ANDROID_BUILD_GUIDE.md](ANDROID_BUILD_GUIDE.md). This is a Capacitor Android source project configuration, not a precompiled APK. An Android SDK/Android Studio build environment is required to generate the APK.
