# QuickBill Android build guide

This folder contains the QuickBill web app and a Capacitor Android wrapper configuration. It is an Android Studio-ready source project; it is not a compiled APK yet.

## Requirements
- Windows/macOS/Linux computer
- Node.js 20 or newer
- Android Studio (current stable)
- Android SDK installed through Android Studio

## Generate the Android project
Open a terminal in this folder and run:

```bash
npm install
npx cap add android
npx cap sync android
npx cap open android
```

If `android` already exists, skip `npx cap add android` and run `npx cap sync android`.

## Build an APK
In Android Studio:
1. Wait for Gradle sync to finish.
2. Connect an Android phone or select an emulator.
3. For a test APK, choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the APK location when the build completes.

For a shareable signed APK, use **Build > Generate Signed Bundle / APK** and create a signing key. Keep the keystore and passwords safe.

## Notes
- App ID: `com.brightways.quickbill`
- App name: `QuickBill`
- Bills/settings are stored locally on the phone. There is no server or cloud sync.
- Export bill history from the old browser version before switching. In the APK, open History > Import previous bill backup to bring those records across. Browser and APK storage are separate.
- The on-screen amount keypad is used; the amount display is read-only and does not request the Android soft keyboard.
- Bills are saved to local history as soon as Generate Bill is tapped.
- Bluetooth printing currently relies on the installed RawBT Android app/print bridge. Test it on the target Shreyans SRS583 before relying on it for shop use. This wrapper does not yet contain a native Bluetooth SPP driver.
